import customtkinter as ctk
import sqlite3
from tkinter import ttk, messagebox
from werkzeug.security import check_password_hash, generate_password_hash

# --- CONFIGURACIÓN DE APARIENCIA ---
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")


# --- CLASE PARA LA VENTANA DE LOGIN ---
class LoginWindow(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Login - HotelPy")
        self.geometry("350x220")
        self.parent = parent
        self.protocol("WM_DELETE_WINDOW", self.parent.destroy)
        self.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(self, text="Inicio de Sesión", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=20, pady=(20, 10))

        self.username_entry = ctk.CTkEntry(self, placeholder_text="Usuario")
        self.username_entry.grid(row=1, column=0, pady=5, padx=20, sticky="ew")
        
        self.password_entry = ctk.CTkEntry(self, placeholder_text="Contraseña", show="*")
        self.password_entry.grid(row=2, column=0, pady=5, padx=20, sticky="ew")
        
        login_button = ctk.CTkButton(self, text="Iniciar Sesión", command=self.attempt_login)
        login_button.grid(row=3, column=0, pady=(15, 20), padx=20, sticky="ew")

        self.transient(self.parent)
        self.grab_set()

    def attempt_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if not username or not password:
            messagebox.showerror("Error", "Usuario y contraseña no pueden estar vacíos.")
            return

        conn = sqlite3.connect('hotel.db')
        cursor = conn.cursor()
        cursor.execute("SELECT password_hash FROM usuarios WHERE username = ?", (username,))
        result = cursor.fetchone()
        conn.close()

        if result and check_password_hash(result[0], password):
            self.parent.after(100, self.parent.deiconify)
            self.destroy()
        else:
            messagebox.showerror("Error de Login", "Usuario o contraseña incorrectos.")


# --- CLASE PRINCIPAL DE LA APLICACIÓN ---
class HotelApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de Gestión de Hotel")
        self.geometry("1200x800")

        self.current_building_id = None
        self.current_view = "personal"
        self.personal_map = {}; self.building_map = {}
        self.selected_staff_id = None
        self.selected_room_id = None
        self.selected_building_id_mgmt = None

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self.setup_top_frame()
        self.setup_nav_frame()

        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.main_frame.grid(row=1, column=1, sticky="nsew", padx=20, pady=(0, 20))
        
        self.update_building_selector()

    def setup_top_frame(self):
        self.top_frame = ctk.CTkFrame(self, height=50, corner_radius=0, fg_color=("#dbdbdb", "#2B2B2B"))
        self.top_frame.grid(row=0, column=0, columnspan=2, sticky="ew")
        
        ctk.CTkLabel(self.top_frame, text="Edificio Actual:", font=ctk.CTkFont(weight="bold")).pack(side="left", padx=(20, 10), pady=10)
        
        self.building_selector = ctk.CTkOptionMenu(self.top_frame, values=[""], command=self.on_building_change)
        self.building_selector.pack(side="left", padx=10, pady=10)

    def setup_nav_frame(self):
        nav_frame = ctk.CTkFrame(self, width=180, corner_radius=0)
        nav_frame.grid(row=1, column=0, sticky="nsew")
        nav_frame.grid_rowconfigure(5, weight=1)
        ctk.CTkLabel(nav_frame, text="HotelPy", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=20, pady=20)
        self.btn_personal = ctk.CTkButton(nav_frame, text="Personal", command=self.mostrar_vista_personal)
        self.btn_personal.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        self.btn_habitaciones = ctk.CTkButton(nav_frame, text="Habitaciones", command=self.mostrar_vista_habitaciones)
        self.btn_habitaciones.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        ctk.CTkLabel(nav_frame, text="Administración", font=ctk.CTkFont(size=12, weight="bold", slant="italic")).grid(row=3, column=0, padx=20, pady=(20, 0), sticky="w")
        self.btn_edificios = ctk.CTkButton(nav_frame, text="Edificios", fg_color="#565b5e", hover_color="#6c7174", command=self.mostrar_vista_edificios)
        self.btn_edificios.grid(row=4, column=0, padx=20, pady=10, sticky="ew")

    def db_connect(self): return sqlite3.connect('hotel.db')

    def limpiar_frame_principal(self):
        for widget in self.main_frame.winfo_children(): widget.destroy()

    def update_building_selector(self):
        edificios = list(self.get_all_buildings_for_map().keys())
        if not edificios: edificios = ["Sin edificios"]
        current_selection = self.building_selector.get()
        self.building_selector.configure(values=edificios)
        if current_selection in edificios:
            self.building_selector.set(current_selection)
            self.on_building_change(current_selection)
        elif edificios[0] != "Sin edificios":
            self.building_selector.set(edificios[0])
            self.on_building_change(edificios[0])
        else:
            self.building_selector.set("Sin edificios")
            self.current_building_id = None
            if self.current_view != "edificios":
                self.mostrar_vista_vacia("No hay edificios. Agregue uno para empezar.")
            
    def get_all_buildings_for_map(self):
        conn = self.db_connect(); cursor = conn.cursor()
        cursor.execute("SELECT id, nombre FROM edificios ORDER BY nombre")
        building_list = cursor.fetchall()
        conn.close()
        self.building_map = {name: id for id, name in building_list}
        return self.building_map

    def get_staff_for_building_map(self, building_id):
        if not building_id: return []
        conn = self.db_connect(); cursor = conn.cursor()
        cursor.execute("SELECT id, nombre_completo FROM personal WHERE id_edificio = ?", (building_id,))
        staff_list = cursor.fetchall()
        conn.close()
        self.personal_map = {name: id for id, name in staff_list}
        return [name for id, name in staff_list]
        
    def on_building_change(self, building_name):
        self.current_building_id = self.building_map.get(building_name)
        if self.current_view == "personal": self.mostrar_vista_personal()
        elif self.current_view == "habitaciones": self.mostrar_vista_habitaciones()

    def mostrar_vista_vacia(self, message):
        self.limpiar_frame_principal()
        ctk.CTkLabel(self.main_frame, text=message, font=ctk.CTkFont(size=18)).pack(expand=True, padx=20, pady=20)

    def mostrar_vista_personal(self):
        self.current_view = "personal"; self.top_frame.grid()
        self.limpiar_frame_principal()
        if not self.current_building_id: self.mostrar_vista_vacia("Seleccione un edificio para ver al personal."); return
        container = ctk.CTkFrame(self.main_frame, fg_color="transparent"); container.pack(fill="both", expand=True)
        self.setup_personal_view(container)

    def mostrar_vista_habitaciones(self):
        self.current_view = "habitaciones"; self.top_frame.grid()
        self.limpiar_frame_principal()
        if not self.current_building_id: self.mostrar_vista_vacia("Seleccione un edificio para ver las habitaciones."); return
        container = ctk.CTkFrame(self.main_frame, fg_color="transparent"); container.pack(fill="both", expand=True)
        self.setup_habitaciones_view(container)
        
    def mostrar_vista_edificios(self):
        self.current_view = "edificios"; self.top_frame.grid_remove()
        self.limpiar_frame_principal()
        container = ctk.CTkFrame(self.main_frame, fg_color="transparent"); container.pack(fill="both", expand=True)
        self.setup_edificios_view(container)


    # --- VISTA Y LÓGICA DE GESTIÓN DE EDIFICIOS ---
    def setup_edificios_view(self, parent_container):
        parent_container.grid_columnconfigure(0, weight=1); parent_container.grid_rowconfigure(1, weight=3); parent_container.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(parent_container, text="Gestión de Edificios", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=10, pady=(10,15), sticky="w")
        
        # Tabla
        tabla_frame = ctk.CTkFrame(parent_container); tabla_frame.grid(row=1, column=0, sticky="nsew", padx=10)
        tabla_frame.grid_columnconfigure(0, weight=1); tabla_frame.grid_rowconfigure(0, weight=1)
        self.tree_edificios = ttk.Treeview(tabla_frame, columns=("ID", "Nombre", "Direccion"), show="headings")
        self.tree_edificios.heading("ID", text="ID"); self.tree_edificios.column("ID", width=50, anchor="center")
        self.tree_edificios.heading("Nombre", text="Nombre del Edificio"); self.tree_edificios.column("Nombre", width=300)
        self.tree_edificios.heading("Direccion", text="Dirección"); self.tree_edificios.column("Direccion", width=400)
        self.tree_edificios.pack(fill="both", expand=True)
        self.refrescar_tabla_edificios()
        self.tree_edificios.bind("<<TreeviewSelect>>", self.on_edificio_select)
        
        # Paneles de Acciones
        acciones_frame = ctk.CTkFrame(parent_container, fg_color="transparent"); acciones_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
        acciones_frame.grid_columnconfigure((0, 1), weight=1)
        
        # Panel Agregar
        agregar_frame = ctk.CTkFrame(acciones_frame, border_width=1); agregar_frame.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="nsew")
        agregar_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(agregar_frame, text="Agregar Nuevo Edificio", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=(5,10))
        self.add_nombre_edificio = ctk.CTkEntry(agregar_frame, placeholder_text="Nombre del Edificio"); self.add_nombre_edificio.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        self.add_direccion_edificio = ctk.CTkEntry(agregar_frame, placeholder_text="Dirección"); self.add_direccion_edificio.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(agregar_frame, text="Agregar Edificio", command=self.agregar_edificio).grid(row=3, column=0, padx=10, pady=10, sticky="ew")

        # Panel Editar/Eliminar
        self.edit_frame_edificio = ctk.CTkFrame(acciones_frame, border_width=1); self.edit_frame_edificio.grid(row=0, column=1, padx=(5, 0), pady=5, sticky="nsew")
        self.edit_frame_edificio.grid_columnconfigure((0,1,2), weight=1)
        ctk.CTkLabel(self.edit_frame_edificio, text="Editar Edificio Seleccionado", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=3, padx=10, pady=(5,10))
        self.edit_nombre_edificio = ctk.CTkEntry(self.edit_frame_edificio); self.edit_nombre_edificio.grid(row=1, column=0, columnspan=3, padx=10, pady=5, sticky="ew")
        self.edit_direccion_edificio = ctk.CTkEntry(self.edit_frame_edificio); self.edit_direccion_edificio.grid(row=2, column=0, columnspan=3, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(self.edit_frame_edificio, text="Actualizar", command=self.actualizar_edificio).grid(row=3, column=0, padx=5, pady=10, sticky="ew")
        ctk.CTkButton(self.edit_frame_edificio, text="Eliminar", fg_color="red", hover_color="#C00000", command=self.eliminar_edificio).grid(row=3, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkButton(self.edit_frame_edificio, text="Limpiar", fg_color="gray", command=self.limpiar_seleccion_edificio).grid(row=3, column=2, padx=5, pady=10, sticky="ew")
        self.toggle_edit_panel_edificio(False)

    def refrescar_tabla_edificios(self):
        for item in self.tree_edificios.get_children(): self.tree_edificios.delete(item)
        conn = self.db_connect(); cursor = conn.cursor()
        for row in cursor.execute("SELECT id, nombre, direccion FROM edificios"): self.tree_edificios.insert("", "end", values=row)
        conn.close()

    def on_edificio_select(self, event):
        selected_item = self.tree_edificios.focus()
        if not selected_item: return
        item_values = self.tree_edificios.item(selected_item, "values"); self.selected_building_id_mgmt = item_values[0]
        self.edit_nombre_edificio.delete(0, "end"); self.edit_nombre_edificio.insert(0, item_values[1])
        self.edit_direccion_edificio.delete(0, "end"); self.edit_direccion_edificio.insert(0, item_values[2])
        self.toggle_edit_panel_edificio(True)

    def agregar_edificio(self):
        nombre = self.add_nombre_edificio.get(); direccion = self.add_direccion_edificio.get()
        if nombre and direccion:
            try:
                conn = self.db_connect(); cursor = conn.cursor()
                cursor.execute("INSERT INTO edificios (nombre, direccion) VALUES (?, ?)", (nombre, direccion))
                conn.commit(); conn.close()
                self.add_nombre_edificio.delete(0, "end"); self.add_direccion_edificio.delete(0, "end")
                self.refrescar_tabla_edificios(); self.update_building_selector()
            except sqlite3.IntegrityError: messagebox.showerror("Error", "Ya existe un edificio con ese nombre.")
        else: messagebox.showwarning("Campos Vacíos", "El nombre y la dirección son obligatorios.")

    def actualizar_edificio(self):
        if not self.selected_building_id_mgmt: return
        nombre = self.edit_nombre_edificio.get(); direccion = self.edit_direccion_edificio.get()
        if nombre and direccion:
            conn = self.db_connect(); cursor = conn.cursor()
            cursor.execute("UPDATE edificios SET nombre = ?, direccion = ? WHERE id = ?", (nombre, direccion, self.selected_building_id_mgmt))
            conn.commit(); conn.close()
            self.refrescar_tabla_edificios(); self.limpiar_seleccion_edificio(); self.update_building_selector()
        else: messagebox.showwarning("Campos Vacíos", "El nombre y la dirección son obligatorios.")

    def eliminar_edificio(self):
        if not self.selected_building_id_mgmt: return
        conn = self.db_connect(); cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM personal WHERE id_edificio = ?", (self.selected_building_id_mgmt,))
        staff_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM habitaciones WHERE id_edificio = ?", (self.selected_building_id_mgmt,))
        room_count = cursor.fetchone()[0]
        
        if staff_count > 0 or room_count > 0:
            messagebox.showerror("Error al Eliminar", f"No se puede eliminar el edificio.\nTiene {staff_count} trabajador(es) y {room_count} habitación(es) asignadas.\nPor favor, reasígnelos o elimínelos primero.")
            conn.close()
            return

        if messagebox.askyesno("Confirmar Eliminación", f"¿Seguro que desea eliminar el edificio '{self.edit_nombre_edificio.get()}'?"):
            cursor.execute("DELETE FROM edificios WHERE id = ?", (self.selected_building_id_mgmt,))
            conn.commit(); conn.close()
            self.refrescar_tabla_edificios(); self.limpiar_seleccion_edificio(); self.update_building_selector()

    def limpiar_seleccion_edificio(self):
        if self.tree_edificios.focus(): self.tree_edificios.selection_remove(self.tree_edificios.focus())
        self.selected_building_id_mgmt = None
        self.edit_nombre_edificio.delete(0, "end"); self.edit_direccion_edificio.delete(0, "end")
        self.edit_nombre_edificio.configure(placeholder_text="Seleccione un edificio"); self.edit_direccion_edificio.configure(placeholder_text="")
        self.toggle_edit_panel_edificio(False)

    def toggle_edit_panel_edificio(self, enabled):
        state = "normal" if enabled else "disabled"
        for child in self.edit_frame_edificio.winfo_children():
            if isinstance(child, (ctk.CTkEntry, ctk.CTkButton)): child.configure(state=state)

    # --- VISTA Y LÓGICA DE PERSONAL ---
    def setup_personal_view(self, parent_container):
        parent_container.grid_columnconfigure(0, weight=1); parent_container.grid_rowconfigure(1, weight=3); parent_container.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(parent_container, text="Gestión de Personal", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=10, pady=(10,15), sticky="w")
        tabla_frame = ctk.CTkFrame(parent_container); tabla_frame.grid(row=1, column=0, sticky="nsew", padx=10)
        tabla_frame.grid_columnconfigure(0, weight=1); tabla_frame.grid_rowconfigure(0, weight=1)
        self.tree_personal = ttk.Treeview(tabla_frame, columns=("ID", "Nombre", "Puesto", "Teléfono"), show="headings")
        self.tree_personal.heading("ID", text="ID"); self.tree_personal.column("ID", width=50, anchor="center")
        self.tree_personal.heading("Nombre", text="Nombre Completo"); self.tree_personal.column("Nombre", width=300)
        self.tree_personal.heading("Puesto", text="Puesto"); self.tree_personal.column("Puesto", width=200)
        self.tree_personal.heading("Teléfono", text="Teléfono"); self.tree_personal.column("Teléfono", width=150)
        self.tree_personal.pack(fill="both", expand=True)
        self.refrescar_tabla_personal()
        self.tree_personal.bind("<<TreeviewSelect>>", self.on_staff_select)
        acciones_frame = ctk.CTkFrame(parent_container, fg_color="transparent"); acciones_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
        acciones_frame.grid_columnconfigure((0, 1), weight=1)
        agregar_frame = ctk.CTkFrame(acciones_frame, border_width=1); agregar_frame.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="nsew")
        agregar_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(agregar_frame, text="Agregar Nuevo Trabajador", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=(5,10))
        self.add_nombre_staff = ctk.CTkEntry(agregar_frame, placeholder_text="Nombre Completo"); self.add_nombre_staff.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        self.add_puesto_staff = ctk.CTkEntry(agregar_frame, placeholder_text="Puesto"); self.add_puesto_staff.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        self.add_telefono_staff = ctk.CTkEntry(agregar_frame, placeholder_text="Teléfono"); self.add_telefono_staff.grid(row=3, column=0, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(agregar_frame, text="Agregar Trabajador", command=self.agregar_personal).grid(row=4, column=0, padx=10, pady=10, sticky="ew")
        self.edit_frame_staff = ctk.CTkFrame(acciones_frame, border_width=1); self.edit_frame_staff.grid(row=0, column=1, padx=(5, 0), pady=5, sticky="nsew")
        self.edit_frame_staff.grid_columnconfigure((0,1,2), weight=1)
        ctk.CTkLabel(self.edit_frame_staff, text="Editar Trabajador Seleccionado", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=3, padx=10, pady=(5,10))
        self.edit_nombre_staff = ctk.CTkEntry(self.edit_frame_staff, placeholder_text="Seleccione a alguien de la lista"); self.edit_nombre_staff.grid(row=1, column=0, columnspan=3, padx=10, pady=5, sticky="ew")
        self.edit_puesto_staff = ctk.CTkEntry(self.edit_frame_staff); self.edit_puesto_staff.grid(row=2, column=0, columnspan=3, padx=10, pady=5, sticky="ew")
        self.edit_telefono_staff = ctk.CTkEntry(self.edit_frame_staff); self.edit_telefono_staff.grid(row=3, column=0, columnspan=3, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(self.edit_frame_staff, text="Actualizar", command=self.actualizar_personal).grid(row=4, column=0, padx=5, pady=10, sticky="ew")
        ctk.CTkButton(self.edit_frame_staff, text="Eliminar", fg_color="red", hover_color="#C00000", command=self.eliminar_personal).grid(row=4, column=1, padx=5, pady=10, sticky="ew")
        ctk.CTkButton(self.edit_frame_staff, text="Limpiar", fg_color="gray", command=self.limpiar_seleccion_personal).grid(row=4, column=2, padx=5, pady=10, sticky="ew")
        self.toggle_edit_panel_staff(False)

    def refrescar_tabla_personal(self):
        for item in self.tree_personal.get_children(): self.tree_personal.delete(item)
        if not self.current_building_id: return
        conn = self.db_connect(); cursor = conn.cursor()
        for row in cursor.execute("SELECT id, nombre_completo, puesto, telefono FROM personal WHERE id_edificio = ?", (self.current_building_id,)):
            self.tree_personal.insert("", "end", values=row)
        conn.close()

    def on_staff_select(self, event):
        selected_item = self.tree_personal.focus()
        if not selected_item: return
        item_values = self.tree_personal.item(selected_item, "values"); self.selected_staff_id = item_values[0]
        self.edit_nombre_staff.delete(0, "end"); self.edit_nombre_staff.insert(0, item_values[1])
        self.edit_puesto_staff.delete(0, "end"); self.edit_puesto_staff.insert(0, item_values[2])
        self.edit_telefono_staff.delete(0, "end"); self.edit_telefono_staff.insert(0, item_values[3])
        self.toggle_edit_panel_staff(True)

    def agregar_personal(self):
        nombre = self.add_nombre_staff.get(); puesto = self.add_puesto_staff.get(); telefono = self.add_telefono_staff.get()
        if nombre and puesto:
            conn = self.db_connect(); cursor = conn.cursor()
            cursor.execute("INSERT INTO personal (id_edificio, nombre_completo, puesto, telefono) VALUES (?, ?, ?, ?)", (self.current_building_id, nombre, puesto, telefono))
            conn.commit(); conn.close()
            self.add_nombre_staff.delete(0, "end"); self.add_puesto_staff.delete(0, "end"); self.add_telefono_staff.delete(0, "end")
            self.refrescar_tabla_personal()
        else: messagebox.showwarning("Campos Vacíos", "El nombre y el puesto son obligatorios.")
    
    def actualizar_personal(self):
        if not self.selected_staff_id: return
        conn = self.db_connect(); cursor = conn.cursor()
        cursor.execute("UPDATE personal SET nombre_completo = ?, puesto = ?, telefono = ? WHERE id = ?", (self.edit_nombre_staff.get(), self.edit_puesto_staff.get(), self.edit_telefono_staff.get(), self.selected_staff_id))
        conn.commit(); conn.close()
        self.refrescar_tabla_personal(); self.limpiar_seleccion_personal()

    def eliminar_personal(self):
        if not self.selected_staff_id: return
        if messagebox.askyesno("Confirmar Eliminación", f"¿Seguro que desea eliminar a {self.edit_nombre_staff.get()}?"):
            conn = self.db_connect(); cursor = conn.cursor()
            cursor.execute("UPDATE habitaciones SET id_personal_asignado = NULL WHERE id_personal_asignado = ?", (self.selected_staff_id,))
            cursor.execute("DELETE FROM personal WHERE id = ?", (self.selected_staff_id,))
            conn.commit(); conn.close()
            self.refrescar_tabla_personal(); self.limpiar_seleccion_personal()

    def limpiar_seleccion_personal(self):
        if self.tree_personal.focus(): self.tree_personal.selection_remove(self.tree_personal.focus())
        self.selected_staff_id = None
        self.edit_nombre_staff.delete(0, "end"); self.edit_puesto_staff.delete(0, "end"); self.edit_telefono_staff.delete(0, "end")
        self.edit_nombre_staff.configure(placeholder_text="Seleccione a alguien de la lista")
        self.toggle_edit_panel_staff(False)

    def toggle_edit_panel_staff(self, enabled):
        state = "normal" if enabled else "disabled"
        for child in self.edit_frame_staff.winfo_children():
            if isinstance(child, (ctk.CTkEntry, ctk.CTkButton)): child.configure(state=state)

    # --- VISTA Y LÓGICA DE HABITACIONES ---
    def setup_habitaciones_view(self, parent_container):
        parent_container.grid_columnconfigure(0, weight=1); parent_container.grid_rowconfigure(1, weight=3); parent_container.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(parent_container, text="Gestión de Habitaciones", font=ctk.CTkFont(size=20, weight="bold")).grid(row=0, column=0, padx=10, pady=(10,15), sticky="w")
        tabla_frame = ctk.CTkFrame(parent_container); tabla_frame.grid(row=1, column=0, sticky="nsew", padx=10)
        tabla_frame.grid_columnconfigure(0, weight=1); tabla_frame.grid_rowconfigure(0, weight=1)
        self.tree_habitaciones = ttk.Treeview(tabla_frame, columns=("ID", "Numero", "Tipo", "Estado", "Disponible", "Personal"), show="headings")
        self.tree_habitaciones.heading("ID", text="ID"); self.tree_habitaciones.column("ID", width=40, anchor="center")
        self.tree_habitaciones.heading("Numero", text="Número"); self.tree_habitaciones.column("Numero", width=80)
        self.tree_habitaciones.heading("Tipo", text="Tipo"); self.tree_habitaciones.column("Tipo", width=100)
        self.tree_habitaciones.heading("Estado", text="Estado"); self.tree_habitaciones.column("Estado", width=100)
        self.tree_habitaciones.heading("Disponible", text="Válido hasta"); self.tree_habitaciones.column("Disponible", width=150)
        self.tree_habitaciones.heading("Personal", text="Personal Asignado"); self.tree_habitaciones.column("Personal", width=200)
        self.tree_habitaciones.pack(fill="both", expand=True)
        self.refrescar_tabla_habitaciones()
        self.tree_habitaciones.bind("<<TreeviewSelect>>", self.on_room_select)
        acciones_frame = ctk.CTkFrame(parent_container, fg_color="transparent"); acciones_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
        acciones_frame.grid_columnconfigure((0, 1), weight=1)
        agregar_frame = ctk.CTkFrame(acciones_frame, border_width=1); agregar_frame.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="nsew")
        agregar_frame.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(agregar_frame, text="Agregar Nueva Habitación", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=(5,10))
        self.add_numero_hab = ctk.CTkEntry(agregar_frame, placeholder_text="Número de Habitación"); self.add_numero_hab.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        self.add_tipo_hab = ctk.CTkOptionMenu(agregar_frame, values=["Individual", "Doble", "Suite", "Matrimonial"]); self.add_tipo_hab.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(agregar_frame, text="Agregar Habitación", command=self.agregar_habitacion).grid(row=3, column=0, padx=10, pady=10, sticky="ew")
        self.edit_frame_room = ctk.CTkFrame(acciones_frame, border_width=1); self.edit_frame_room.grid(row=0, column=1, padx=(5, 0), pady=5, sticky="nsew")
        self.edit_frame_room.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(self.edit_frame_room, text="Editar Habitación Seleccionada", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=2, padx=10, pady=(5,10))
        self.edit_estado_hab = ctk.CTkOptionMenu(self.edit_frame_room, values=["Disponible", "Ocupada", "Mantenimiento"]); self.edit_estado_hab.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        staff_names = self.get_staff_for_building_map(self.current_building_id or 0); staff_names.insert(0, "Ninguno")
        self.edit_personal_hab = ctk.CTkOptionMenu(self.edit_frame_room, values=staff_names); self.edit_personal_hab.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(self.edit_frame_room, text="Actualizar Habitación", command=self.actualizar_habitacion).grid(row=3, column=0, padx=10, pady=10, sticky="ew")
        self.toggle_edit_panel_room(False)

    def refrescar_tabla_habitaciones(self):
        for item in self.tree_habitaciones.get_children(): self.tree_habitaciones.delete(item)
        if not self.current_building_id: return
        conn = self.db_connect(); cursor = conn.cursor()
        query = """SELECT h.id, h.numero_habitacion, h.tipo, h.estado, h.fecha_disponible, p.nombre_completo FROM habitaciones h LEFT JOIN personal p ON h.id_personal_asignado = p.id WHERE h.id_edificio = ?"""
        for row in cursor.execute(query, (self.current_building_id,)):
            personal = row[5] if row[5] else "Sin asignar"; fecha = row[4] if row[4] else ""
            self.tree_habitaciones.insert("", "end", values=(row[0], row[1], row[2], row[3], fecha, personal))
        conn.close()

    def on_room_select(self, event):
        selected_item = self.tree_habitaciones.focus()
        if not selected_item: return
        item_values = self.tree_habitaciones.item(selected_item, "values"); self.selected_room_id = item_values[0]
        self.edit_estado_hab.set(item_values[3])
        staff_names = self.get_staff_for_building_map(self.current_building_id); staff_names.insert(0, "Ninguno")
        self.edit_personal_hab.configure(values=staff_names)
        self.edit_personal_hab.set(item_values[5] if item_values[5] != "Sin asignar" else "Ninguno")
        self.toggle_edit_panel_room(True)

    def agregar_habitacion(self):
        numero = self.add_numero_hab.get(); tipo = self.add_tipo_hab.get()
        if numero and tipo:
            conn = self.db_connect(); cursor = conn.cursor()
            cursor.execute("INSERT INTO habitaciones (id_edificio, numero_habitacion, tipo) VALUES (?, ?, ?)", (self.current_building_id, numero, tipo))
            conn.commit(); conn.close()
            self.add_numero_hab.delete(0, "end"); self.refrescar_tabla_habitaciones()
        else: messagebox.showwarning("Campos Vacíos", "El número y tipo son obligatorios.")

    def actualizar_habitacion(self):
        if not self.selected_room_id: return
        nuevo_estado = self.edit_estado_hab.get(); fecha_disp = None
        if nuevo_estado in ["Ocupada", "Mantenimiento"]:
            dialog = ctk.CTkInputDialog(text=f"¿Hasta qué fecha/hora estará '{nuevo_estado}'?\nFormato Sugerido: AAAA-MM-DD HH:MM", title="Confirmar Fecha")
            fecha_disp = dialog.get_input()
            if not fecha_disp: return
        personal_nombre = self.edit_personal_hab.get()
        personal_id = self.personal_map.get(personal_nombre) if personal_nombre != "Ninguno" else None
        params = (nuevo_estado, personal_id, fecha_disp if nuevo_estado != "Disponible" else None, self.selected_room_id)
        conn = self.db_connect(); cursor = conn.cursor()
        cursor.execute("UPDATE habitaciones SET estado = ?, id_personal_asignado = ?, fecha_disponible = ? WHERE id = ?", params)
        conn.commit(); conn.close()
        self.refrescar_tabla_habitaciones(); self.toggle_edit_panel_room(False); self.selected_room_id = None

    def toggle_edit_panel_room(self, enabled):
        state = "normal" if enabled else "disabled"
        for child in self.edit_frame_room.winfo_children():
            if isinstance(child, (ctk.CTkOptionMenu, ctk.CTkButton)): child.configure(state=state)

# --- PUNTO DE ENTRADA DE LA APLICACIÓN ---
if __name__ == "__main__":
    app = HotelApp()
    app.withdraw()
    login_window = LoginWindow(app)
    app.mainloop()